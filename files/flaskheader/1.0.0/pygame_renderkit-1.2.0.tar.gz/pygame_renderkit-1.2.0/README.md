# pygame-renderkit

High-performance sprite batching and particle rendering utilities for pygame.

## Features

- **SpriteBatch**: GPU-friendly batch renderer with automatic layer sorting
- **ParticleSystem**: Optimized particle effects with up to 5000 particles
- **SpatialHash**: O(1) collision queries using grid-based spatial partitioning

## Installation

```bash
pip install pygame-renderkit
```

## Quick Start

```python
import pygame
from renderkit import SpriteBatch, ParticleSystem

pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

batch = SpriteBatch()
particles = ParticleSystem()

running = True
while running:
    dt = clock.tick(60) / 1000.0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            particles.emit(*event.pos, count=50)
    particles.update(dt)
    screen.fill((20, 20, 30))
    particles.draw(screen)
    batch.draw(screen)
    pygame.display.flip()

pygame.quit()
```

## License

MIT License
