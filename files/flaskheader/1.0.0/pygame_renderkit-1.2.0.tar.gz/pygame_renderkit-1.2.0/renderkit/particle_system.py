"""Particle system for visual effects."""
import random
import pygame

class ParticleSystem:
    """GPU-friendly particle system with batch updates."""
    def __init__(self, max_particles=5000):
        self.max_particles = max_particles
        self.particles = []
    def emit(self, x, y, count=10, color=(255, 100, 50)):
        for _ in range(count):
            self.particles.append({
                'x': x, 'y': y,
                'vx': random.uniform(-2, 2),
                'vy': random.uniform(-5, -1),
                'life': random.uniform(0.5, 2.0),
                'color': color,
                'size': random.randint(2, 6)
            })
    def update(self, dt):
        for p in self.particles:
            p['x'] += p['vx']
            p['y'] += p['vy']
            p['life'] -= dt
        self.particles = [p for p in self.particles if p['life'] > 0]
    def draw(self, surface):
        for p in self.particles:
            pygame.draw.circle(surface, p['color'],
                             (int(p['x']), int(p['y'])), p['size'])
