"""
pygame-renderkit: High-performance sprite batching for pygame
Provides optimized sprite batch rendering, particle systems, and
collision-optimized spatial hashing for 2D games.
"""

__version__ = '1.2.0'
__author__ = 'DevStudio Games'

from .sprite_batch import SpriteBatch
from .particle_system import ParticleSystem
from .spatial_hash import SpatialHash

__all__ = ['SpriteBatch', 'ParticleSystem', 'SpatialHash']
