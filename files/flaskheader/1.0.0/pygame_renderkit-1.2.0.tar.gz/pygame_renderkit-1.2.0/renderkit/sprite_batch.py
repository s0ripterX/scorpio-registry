"""Optimized sprite batch renderer."""
import pygame

class SpriteBatch:
    """Batch renderer for pygame sprites with layer sorting."""
    def __init__(self, max_sprites=10000):
        self.max_sprites = max_sprites
        self.sprites = []
        self._dirty = True
    def add(self, sprite, layer=0):
        self.sprites.append((layer, sprite))
        self._dirty = True
    def remove(self, sprite):
        self.sprites = [s for s in self.sprites if s[1] != sprite]
        self._dirty = True
    def draw(self, surface):
        if self._dirty:
            self.sprites.sort(key=lambda x: x[0])
            self._dirty = False
        for _, sprite in self.sprites:
            surface.blit(sprite.image, sprite.rect)
