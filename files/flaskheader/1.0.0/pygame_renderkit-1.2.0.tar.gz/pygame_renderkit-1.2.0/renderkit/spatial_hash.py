"""Spatial hashing for collision detection."""

class SpatialHash:
    """Grid-based spatial partitioning for O(1) collision queries."""
    def __init__(self, cell_size=64):
        self.cell_size = cell_size
        self.cells = {}
    def _key(self, x, y):
        return (int(x // self.cell_size), int(y // self.cell_size))
    def insert(self, obj, rect):
        min_cell = self._key(rect.left, rect.top)
        max_cell = self._key(rect.right, rect.bottom)
        for cx in range(min_cell[0], max_cell[0] + 1):
            for cy in range(min_cell[1], max_cell[1] + 1):
                k = (cx, cy)
                if k not in self.cells:
                    self.cells[k] = []
                self.cells[k].append(obj)
    def query(self, rect):
        result = set()
        min_cell = self._key(rect.left, rect.top)
        max_cell = self._key(rect.right, rect.bottom)
        for cx in range(min_cell[0], max_cell[0] + 1):
            for cy in range(min_cell[1], max_cell[1] + 1):
                k = (cx, cy)
                if k in self.cells:
                    result.update(self.cells[k])
        return list(result)
    def clear(self):
        self.cells.clear()
